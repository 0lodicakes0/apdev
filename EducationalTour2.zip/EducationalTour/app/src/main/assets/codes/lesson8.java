public class Human {

	// class constructor
	public Human() {

	}

}
