
	
	Human spiderMan = new Human();

	Human batMan = new Human();

	Human you = new Human();

	Human me = new Human();
	
	
