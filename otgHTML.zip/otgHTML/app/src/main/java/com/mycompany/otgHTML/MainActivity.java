package com.mycompany.otgHTML;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.Toast;
import java.io.IOException;
import java.io.FileWriter;

public class MainActivity extends Activity 
{
	private EditText html_text;
	private EditText file_title;
	private Button save_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		
		save_btn = findViewById(R.id.save);
		html_text = findViewById(R.id.html_text);
		file_title = findViewById(R.id.file_title);
		
		
		save_btn.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				String filename = file_title.getText().toString();
				String htmlcode = html_text.getText().toString();
				
				if(filename.length()>0){
					
					try{
						
						FileWriter htmlfile = new FileWriter("/storage/emulated/0/".concat(filename).concat(".html"));
						htmlfile.write
						(htmlcode);
						htmlfile.close();
						Toast.makeText(getApplicationContext(),"File saved",Toast.LENGTH_LONG).show();
					
					
						
					}catch(IOException e){
						
					}
				}else{
					
					Toast.makeText(getApplicationContext(),"Enter file name",Toast.LENGTH_LONG).show();
				}
				
				
			}
			
		});
    }
}
