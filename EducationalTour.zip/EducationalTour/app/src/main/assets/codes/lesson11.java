
	String line = "Tom is a cat.";
	int age = 120; // Who live this long?
	float degree = 360.0f;
	double balance = 0.0; // Spent up!
	boolean isEarthSquare = false;
	char charactor = 'a';
	StringBuilder mStringBuilder;
	InputStream is;
	Human human;
	
	// And you name them ...
	
	
