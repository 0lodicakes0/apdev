# AIDEtour
AIDEtour app demonstrates AIDE-like code highlighting.

### Creating Lessons

Just add lesson(number) files under "talks/" in assets for texts.

If your lesson refers or contains code snippets:
-Create a file with the name "lesson(number)" under "codes/" in assets
-Add these file extensions to the created file 
	- .java (for java codes)
	- .xml (for xml files)
	- no extension for (AndroidManifest.xml codes)

